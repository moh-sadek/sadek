# Change Log

## [1.0.2] 2020-02-07
### Fixed broken links
### Small bug fixing
### Erased hidden dropdown from documentation navbar
### Update devDependencies and gulp

## [1.0.1] 2020-02-05
### Fixed broken links

## [1.0.0] 2019-09-20
### Original Release
